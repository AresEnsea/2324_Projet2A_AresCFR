
#ifndef _PLATFORM_H_
#define _PLATFORM_H_
#pragma once

#include "stm32f4xx.h"

uint16_t ReadRegister32(uint16_t dev, uint16_t RegisterAdress);
uint16_t ReadRegister16(uint16_t dev, uint16_t registerAddr);
uint8_t ReadRegister8(uint16_t dev, uint16_t registerAddr);
void WriteRegister8(uint16_t dev, uint16_t registerAddr, uint8_t value);
void WriteRegister16(uint16_t dev, uint16_t RegisterAdress, uint16_t value);
void WriteRegister32(uint16_t dev, uint16_t RegisterAdress, uint32_t value);
void WaitMs(uint32_t TimeMs);

#endif
